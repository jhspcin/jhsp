import sys

TODO_FILE = 'todo.txt'
ARCHIVE_FILE = 'done.txt'

RED = "\033[1;31m"
BLUE = "\033[1;34m"
CYAN = "\033[1;36m"
GREEN = "\033[0;32m"
RESET = "\033[0;0m"
BOLD = "\033[;1m"
REVERSE = "\033[;7m"
YELLOW = "\033[0;33m"

ADICIONAR = 'a'
REMOVER = 'r'
FAZER = 'f'
PRIORIZAR = 'p'
LISTAR = 'l'


# Imprime texto com cores. Por exemplo, para imprimir "Oi mundo!" em vermelho, basta usar
#
# printCores('Oi mundo!', RED)
# printCores('Texto amarelo e negrito', YELLOW + BOLD)

def printCores(texto, cor):
    print(cor + texto + RESET)

def escreverTodo(novaAtividade):
    try:
        fp = open(TODO_FILE, 'a')
        fp.write(novaAtividade + "\n")
        fp.close()
    except IOError as err:
        print("Não foi possível escrever para o arquivo " + TODO_FILE)
        print(err)
        return False

    return True

# Adiciona um compromisso aa agenda. Um compromisso tem no minimo
# uma descrição. Adicionalmente, pode ter, em caráter opcional, uma
# data (formato DDMMAAAA), um horário (formato HHMM), uma prioridade de A a Z, 
# um contexto onde a atividade será realizada (precedido pelo caractere
# '@') e um projeto do qual faz parte (precedido pelo caractere '+'). Esses
# itens opcionais são os elementos da tupla "extras", o segundo parâmetro da
# função.
#
# extras ~ (data, hora, prioridade, contexto, projeto)
#
# Qualquer elemento da tupla que contenha um string vazio ('') não
# deve ser levado em consideração. 
def adicionar(descricao, extras):
    # não é possível adicionar uma atividade que não possui descrição.
    itens = []
    data = ''
    hora = ''
    pri = ''
    desc = ''
    contexto = ''
    projeto = ''
    for l in extras:
        l = l.strip()  # remove espaços em branco e quebras de linha do começo e do fim
        tokens = l.split(" ")
        for x in tokens:
            if len(tokens) == 0:
                break
            if dataValida(tokens[0]) == True:
                data = tokens[0]
                del (tokens[0])
            if len(tokens) == 0:
                break
            if horaValida(tokens[0]) == True:
                hora = tokens[0]
                del (tokens[0])
            if len(tokens) == 0:
                break
            if prioridadeValida(tokens[0]) == True:
                pri = tokens[0]
                del (tokens[0])
            if len(tokens) == 0:
                break
            if contextoValido(tokens[0]) == True:
                contexto = tokens[0]
                del (tokens[0])
            if len(tokens) == 0:
                break
            if projetoValido(tokens[0]) == True:
                projeto = tokens[0]
                del (tokens[0])
    desc = descricao
    if data != '':
        itens.append(data)
    if hora != '':
        itens.append(hora)
    if pri != '':
        itens.append(pri)
    itens.append(desc)
    if contexto != '':
        itens.append(contexto)
    if projeto != '':
        itens.append(projeto)
    itens = ' '.join(itens)
    escreverTodo(itens)


def in_manual(lista, elemento):
    for x in lista:
        if x == elemento:
            return True
    return False


def hora(string):
    if len(string) == 4:
        return [string[0] + string[1], string[2] + string[3]]


def datificar(string):
    return [string[0] + string[1], string[2] + string[3], string[4] + string[5] + string[6] + string[7]]


# Valida a prioridade.
def prioridadeValida(pri):
    pri = pri.upper()
    if (len(pri) == 3) and (pri == f'({pri[1]})') and (in_manual(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), pri[1])):
        return True
    return False


# Valida a hora. Consideramos que o dia tem 24 horas, como no Brasil, ao invés
# de dois blocos de 12 (AM e PM), como nos EUA.
def horaValida(horaMin):
    if len(horaMin) != 4 or not soDigitos(horaMin):
        return False
    else:
        horas = hora(horaMin)
        if (horas[0] > '23' or horas[0] < '00') or (horas[1] > '59' or horas[1] < '00'):
            return False
        return True


# Valida datas. Verificar inclusive se não estamos tentando
# colocar 31 dias em fevereiro. Não precisamos nos certificar, porém,
# de que um ano é bissexto. 
def dataValida(data):
    if len(data) != 8 or not soDigitos(data):
        return False
    else:
        datas = datificar(data)
        if not (datas[0] > '31' or datas[0] < '00') and not (datas[1] > '12' or datas[1] < '00'):
            if not (in_manual(datas[1], ['04', '06', '09', '11']) and datas[0] > '30') and not (
                    datas[1] == '02' and datas[0] > '29'):
                return True
    return False


# Valida que o string do projeto está no formato correto.
def projetoValido(proj):
    if len(proj) >= 2 and proj[0] == '+':
        return True
    return False


# Valida que o string do contexto está no formato correto.
def contextoValido(cont):
    if len(cont) >= 2 and cont[0] == '@':
        return True
    return False


# Valida que a data ou a hora contém apenas dígitos, desprezando espaços
# extras no início e no fim.
def soDigitos(numero):
    if type(numero) != str:
        return False
    for x in numero:
        if x < '0' or x > '9':
            return False
    return True


# Dadas as linhas de texto obtidas a partir do arquivo texto todo.txt, devolve
# uma lista de tuplas contendo os pedaços de cada linha, conforme o seguinte
# formato:
#
# (descrição, prioridade, (data, hora, contexto, projeto))
#
# É importante lembrar que linhas do arquivo todo.txt devem estar organizadas de acordo com o
# seguinte formato:
#
# DDMMAAAA HHMM (P) DESC @CONTEXT +PROJ
#
# Todos os itens menos DESC são opcionais. Se qualquer um deles estiver fora do formato, por exemplo,
# data que não tem todos os componentes ou prioridade com mais de um caractere (além dos parênteses),
# tudo que vier depois será considerado parte da descrição.  
def organizar(linhas):
    if type(linhas) == list:
        linhas = ' '.join(linhas)
    itens = []
    data = ''
    hora = ''
    pri = ''
    desc = ''
    contexto = ''
    projeto = ''
    for l in linhas:
        l = linhas.strip()  # remove espaços em branco e quebras de linha do começo e do fim
        tokens = l.split()
        for x in tokens:
            if dataValida(tokens[0]):
                data = tokens.pop(0)
            if horaValida(tokens[0]):
                hora = tokens.pop(0)
            if prioridadeValida(tokens[0]):
                pri = tokens.pop(0)
            if contextoValido(tokens[-1]):
                contexto = tokens.pop(-1)
            if projetoValido(tokens[-1]):
                projeto = tokens.pop(-1)
    desc = ' '.join(tokens)
    itens.append((desc, (data, hora, pri, contexto, projeto)))

    return itens


# Datas e horas são armazenadas nos formatos DDMMAAAA e HHMM, mas são exibidas
# como se espera (com os separadores apropridados). 
#
# Uma extensão possível é listar com base em diversos critérios: (i) atividades com certa prioridade;
# (ii) atividades a ser realizadas em certo contexto; (iii) atividades associadas com
# determinado projeto; (vi) atividades de determinado dia (data específica, hoje ou amanhã). Isso não
# é uma das tarefas básicas do projeto, porém. 
def listar():
    arquivo = open('todo.txt', 'r')
    texto = arquivo.readlines()
    temp = []
    for linha in texto:
        organizar(linha)
        temp.append(ordenarPorDataHora(organizar(linha)))
    arquivo.close()
    arquivo2 = open('todo.txt', 'w')
    for x in texto:
      arquivo2.write(x)
    return [x for x in temp[0]]

def conc(lista):
    if len(lista) == 0:
        return ''
    else:
        return lista.pop(0) + conc(lista)


def ordenarporPrioridade(itens):
    tamanho = len(itens) - 1
    for y in range(len(itens)):
        for x in range(len(itens)):
            if x + 1 <= tamanho:
                if itens[x][1][2] == '':
                    itens.append(itens.pop(x))
                if itens[x][1][2] != '' and itens[x + 1][1][2] != '':
                    elementos = len(itens[0][1]) - 1
                    ordenado = False
                    while not ordenado:
                        ordenado = True
                        for i in range(elementos):
                            if itens[x][1][2][1] > itens[x + 1][1][2][1]:
                                itens[x], itens[x + 1] = itens[x + 1], itens[x]
                                ordenado = False

    return itens


def ordenarPorDataHora(itens):
    tamanho = len(itens) - 1
    for y in range(tamanho):
        for x in range(tamanho):
            if x < len(itens) - 1:
                if itens[x][1][0] == '' and itens[x][1][1] == '' and itens[x][1][2] == '':
                    itens.append(itens.pop(x))
                elif itens[x][1][0] == '' and [x + 1][1][0] == '' and [x][1][1] != '' and [x + 1][1][1] != '':
                    hora1 = int([x][1][1])
                    hora2 = int([x + 1][1][1])
                    if hora1 > hora2:
                        itens[x], itens[x + 1] = itens[x + 1], itens[x]

                if itens[x][1][2] == itens[x + 1][1][2]:  # Comparando as prioridades dos elementos
                    if x + 1 <= tamanho:
                        if itens[x][1][0] != '' and itens[x + 1][1][0] != '':
                            elementos = len(itens) - 1
                            ano1 = int(itens[x][1][0][4:])
                            ano2 = int(itens[x + 1][1][0][4:])
                            if x + 1 <= tamanho:
                                if ano1 > ano2:
                                    itens[x], itens[x + 1] = itens[x + 1], itens[x]
                                if ano1 == ano2:
                                    mes1 = int((itens[x][1][0][2:5]))
                                    mes2 = int((itens[x + 1][1][0][2:5]))
                                    if mes1 > mes2:
                                        itens[x], itens[x + 1] = itens[x + 1], itens[x]
                                    if mes1 == mes2:
                                        dia1 = int(itens[x][1][0][0:2])
                                        dia2 = int(itens[x + 1][1][0][0:2])
                                        if dia1 > dia2:
                                            itens[x], itens[x + 1] = itens[x + 1], itens[x]
                                        if dia1 == dia2:
                                            hora1 = int([x][1][1])
                                            hora2 = int([x + 1][1][1])
                                            if hora1 > hora2:
                                                itens[x], itens[x + 1] = itens[x + 1], itens[x]

    return itens


def fazer(num):
  arquivo = open('todo.txt', 'r')
  feito = arquivo.readline(num)
  linhas = arquivo.readlines()
  arquivo.close()
  arquivo = open('todo.txt', 'w')
  for x in linhas:
    if x != feito:
      arquivo.write(x)
  arquivo.close()
  arquivo2 = open('done,txt', 'a')
  arquivo2.write(feito)
  arquivo2.close()


def remover(num):
  arquivo = open('todo.txt', 'r')
  removido = arquivo.readline(num)
  linhas = arquivo.readlines()
  arquivo.close()
  arquivo = open('todo.txt', 'w')
  for x in linhas:
    if x != removido:
      arquivo.write(x)
  arquivo.close()


# prioridade é uma letra entre A a Z, onde A é a mais alta e Z a mais baixa.
# num é o número da atividade cuja prioridade se planeja modificar, conforme
# exibido pelo comando 'l'. 
def priorizar(num, prioridade):
  arquivo = open('todo.txt', 'r')
  escolhido = arquivo.readline(num)
  linhas = arquivo.readlines()
  novoEscolhido = ''
  arquivo.close()
  arquivo2 = open('todo.txt', 'w')
  if len(escolhido) >= 3:
    if escolhido[0] == '(' and escolhido[2] == ')':
      novoEscolhido = '(' + str(prioridade) + ') ' + escolhido[4:len(escolhido)]
    else:
      novoEscolhido = '(' + str(prioridade) + ') ' + escolhido
  for x in linhas:
    if x == escolhido:
      arquivo2.write(novoEscolhido)
    else:
      arquivo2.write(x)
  arquivo.close()


# Esta função processa os comandos e informações passados através da linha de comando e identifica
# que função do programa deve ser invocada. Por exemplo, se o comando 'adicionar' foi usado,
# isso significa que a função adicionar() deve ser invocada para registrar a nova atividade.
# O bloco principal fica responsável também por tirar espaços em branco no início e fim dos strings
# usando o método strip(). Além disso, realiza a validação de horas, datas, prioridades, contextos e
# projetos. 
def processarComandos(comandos):
    if comandos[1] == ADICIONAR:
        comandos.pop(0)  # remove 'agenda.py'
        comandos.pop(0)  # remove ''a''
        itemParaAdicionar = organizar(comandos)
        # itemParaAdicionar = (descricao, (prioridade, data, hora, contexto, projeto))
        if not IndexError:
            adicionar(itemParaAdicionar[0], itemParaAdicionar[1])  # novos itens não têm prioridade

    elif comandos[1] == LISTAR:
        for x in listar():
            cor = ''
        if x[1][2] == 'A':
            cor = RED + BOLD
        elif x[1][2] == 'B':
            cor = YELLOW
        elif x[1][2] == 'C':
            cor = GREEN
        elif x[1][2] == 'B':
            cor = CYAN
        printCores(f'{x[1][2]} {x[1][0]} {x[1][1]} {x[0][0]} {x[1][3]} {x[1][4]}', cor)

    elif comandos[1] == REMOVER:
        remover(comandos[3])

    elif comandos[1] == FAZER:
        fazer(comandos[3])

    elif comandos[1] == PRIORIZAR:
        priorizar(comandos[3], comandos[5])

processarComandos(sys.argv)